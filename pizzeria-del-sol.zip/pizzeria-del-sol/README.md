# Pizzeria del Sol — 3D takeaway website

A cinematic React + Vite starter for a pizza takeaway brand. It includes a live Three.js pizza scene, animated sections, a menu, pizza customization, a cart, and a demo pickup checkout.

## Run locally

Requirements: Node.js 18+ (Node 20 LTS recommended).

```bash
npm install
npm run dev
```

Open the local URL Vite prints (usually http://localhost:5173).

Create a production build:

```bash
npm run build
npm run preview
```

## What works now

- Animated 3D pizza scene built from Three.js meshes (rotating pizza, lighting, floating motion, sparkles and oven glow).
- Responsive cinematic landing page.
- Menu filters and six sample pizzas.
- Pizza customization: small / regular / large and extra toppings.
- Cart quantity controls and calculated totals.
- Pickup checkout form with a demo confirmation.

## Important before using this for a real restaurant

This is a front-end prototype. Prices, menu, pickup details, and contact information are sample content. The checkout is intentionally a demo: it does not charge a customer, send an order to a restaurant, or reserve a pickup slot.

For real orders, add:
1. A backend/API (for example, Firebase Functions or a small Node server) to validate prices and store orders.
2. A payment provider such as Stripe Checkout, configured with server-side secrets (never put secret keys in frontend code).
3. A real restaurant address, opening hours, phone number, tax details, and allergy information.
4. A proper 3D asset if you want even more realistic cheese stretching, sauce spreading, and ingredient placement. The current pizza is generated from 3D geometry so it is lightweight and interactive; it is not a photorealistic scanned model.

## Main files

- `src/App.jsx` — menu, customization, cart, checkout and page sections.
- `src/PizzaScene.jsx` — animated 3D pizza scene.
- `src/styles.css` — responsive styling and animations.
