import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Flame, ShoppingBag, Plus, Minus, X, ArrowUpRight, Clock3, MapPin, Check, ChefHat, ChevronDown, Menu as MenuIcon } from 'lucide-react';
import PizzaScene from './PizzaScene.jsx';

const pizzas = [
  { id: 1, name: 'The Sol', category: 'Signature', description: 'Tomato, fior di latte, pepperoni, basil, hot honey.', price: 12.9, tag: 'BESTSELLER', color: '#d36a39', image: 'pepperoni' },
  { id: 2, name: 'Margherita', category: 'Classics', description: 'San Marzano tomato, mozzarella, fresh basil.', price: 9.5, tag: 'THE CLASSIC', color: '#69905b', image: 'margherita' },
  { id: 3, name: 'Four Cheese', category: 'Signature', description: 'Mozzarella, gorgonzola, parmesan, creamy ricotta.', price: 11.9, tag: 'CHEESE LOVERS', color: '#d9b36d', image: 'cheese' },
  { id: 4, name: 'Spicy Diablo', category: 'Signature', description: 'Spicy salami, chilli, red onion, mozzarella.', price: 12.5, tag: 'A LITTLE HEAT', color: '#bb4731', image: 'spicy' },
  { id: 5, name: 'Garden Verde', category: 'Veggie', description: 'Roasted peppers, olives, red onion, basil pesto.', price: 10.9, tag: 'VEGGIE', color: '#73966a', image: 'veggie' },
  { id: 6, name: 'BBQ Smokehouse', category: 'Signature', description: 'Smoky BBQ sauce, chicken, red onion, mozzarella.', price: 12.9, tag: 'SMOKY & RICH', color: '#9c6442', image: 'bbq' }
];
const money = n => `€${n.toFixed(2)}`;

function PizzaArtwork({ kind = 'pepperoni', small = false }) {
  const toppings = kind === 'margherita' ? '🍃' : kind === 'cheese' ? '🧀' : kind === 'veggie' ? '🫑' : kind === 'bbq' ? '🍗' : '🍕';
  return <div className={`pizza-art pizza-art-${kind} ${small ? 'pizza-art-small' : ''}`}>
    <div className="pizza-art-shadow" />
    <div className="pizza-art-base">
      <div className="pizza-art-sauce" />
      <div className="pizza-art-cheese" />
      {kind !== 'margherita' && kind !== 'cheese' && Array.from({length: kind==='veggie'?8:9}).map((_,i)=>
        <span key={i} className={`topping topping-${i}`} />
      )}
      {kind === 'margherita' && <span className="basil basil-a">✦</span>}
      {kind === 'margherita' && <span className="basil basil-b">✦</span>}
      {kind === 'cheese' && <span className="cheese-pool">✦</span>}
    </div>
    <span className="pizza-art-garnish">{toppings}</span>
  </div>;
}

function Header({ cartCount, onCart, onMenu }) {
  return <header className="header">
    <a className="brand" href="#home" aria-label="Pizzeria del Sol home">
      <span className="brand-mark"><Flame size={22} strokeWidth={2.3}/></span>
      <span><strong>PIZZERIA</strong><small>DEL SOL</small></span>
    </a>
    <nav className="desktop-nav"><a href="#menu">The menu</a><a href="#story">Our craft</a><a href="#pickup">Pickup info</a></nav>
    <div className="header-actions">
      <button className="cart-button" onClick={onCart}><ShoppingBag size={17}/><span>Order</span><b>{cartCount}</b></button>
      <button className="mobile-menu" onClick={onMenu} aria-label="Open menu"><MenuIcon size={22}/></button>
    </div>
  </header>;
}

function CartDrawer({ open, onClose, cart, setCart, onCheckout }) {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const update = (key, delta) => setCart(old => old.map(i => i.key === key ? {...i, qty: i.qty + delta} : i).filter(i => i.qty > 0));
  return <AnimatePresence>
    {open && <>
      <motion.div className="drawer-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}/>
      <motion.aside className="cart-drawer" initial={{x:'100%'}} animate={{x:0}} exit={{x:'100%'}} transition={{type:'spring', damping:28, stiffness:260}}>
        <div className="drawer-head"><div><span className="eyebrow">YOUR ORDER</span><h2>Good choice.</h2></div><button className="icon-button" onClick={onClose}><X/></button></div>
        {cart.length === 0 ? <div className="empty-cart"><span className="empty-icon">🍕</span><h3>Your cart is hungry.</h3><p>Add a pizza and we'll get the oven going.</p><button className="button button-primary" onClick={onClose}>Explore the menu</button></div> :
          <><div className="cart-items">{cart.map(item=><div className="cart-item" key={item.key}>
            <PizzaArtwork kind={item.image} small/><div className="cart-item-info"><strong>{item.name}</strong><small>{item.size} · {item.toppings.length ? item.toppings.join(', ') : 'Original recipe'}</small><b>{money(item.price*item.qty)}</b><div className="quantity"><button onClick={()=>update(item.key,-1)} aria-label="Remove one"><Minus size={13}/></button><span>{item.qty}</span><button onClick={()=>update(item.key,1)} aria-label="Add one"><Plus size={13}/></button></div></div>
          </div>)}</div>
          <div className="cart-summary"><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>Pickup</span><span className="free-label">Free</span></div><div className="total-line"><span>Total</span><strong>{money(subtotal)}</strong></div><button className="button button-primary button-full" onClick={onCheckout}>Continue to pickup <ArrowUpRight size={17}/></button><p className="cart-note"><Clock3 size={14}/> Estimated pickup: 20–30 minutes</p></div></>}
      </motion.aside>
    </>}
  </AnimatePresence>;
}

function CheckoutModal({ open, onClose, cart, onSuccess }) {
  const [name,setName] = useState('');
  const [phone,setPhone] = useState('');
  const [pickup,setPickup] = useState('ASAP · 25 min');
  const [submitted,setSubmitted] = useState(false);
  const total = cart.reduce((sum,item)=>sum+item.price*item.qty,0);
  const submit = e => { e.preventDefault(); if (!cart.length) return; setSubmitted(true); onSuccess({name, phone, pickup, total, orderNo: Math.floor(1000+Math.random()*8999)}); };
  return <AnimatePresence>{open && <motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}>
    <motion.div className="checkout-modal" initial={{opacity:0,y:20,scale:.98}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:12}} onClick={e=>e.stopPropagation()}>
      <button className="modal-close icon-button" onClick={onClose}><X/></button>
      {submitted ? <div className="success-state"><div className="success-mark"><Check size={30}/></div><span className="eyebrow">ORDER PREVIEW</span><h2>That's a wrap.</h2><p>Your demo order is ready to go. No payment has been taken and the restaurant has not received this order.</p><button className="button button-primary button-full" onClick={onClose}>Back to the restaurant</button></div> :
      <><span className="eyebrow">PICKUP, MADE EASY</span><h2>Let's get your pizza.</h2><p className="modal-subtitle">A few details, then your order summary.</p>
        <form onSubmit={submit} className="checkout-form">
          <label>Your name<input value={name} onChange={e=>setName(e.target.value)} required placeholder="Name for the order"/></label>
          <label>Phone number<input value={phone} onChange={e=>setPhone(e.target.value)} required type="tel" placeholder="For pickup updates"/></label>
          <label>Pickup time<select value={pickup} onChange={e=>setPickup(e.target.value)}><option>ASAP · 25 min</option><option>In 45 minutes</option><option>In 1 hour</option></select></label>
          <div className="checkout-total"><span>Order total</span><strong>{money(total)}</strong></div>
          <button className="button button-primary button-full" type="submit">Review demo order <ArrowUpRight size={17}/></button>
          <p className="demo-disclaimer">Demo checkout only · no payment processing</p>
        </form>
      </>}
    </motion.div>
  </motion.div>}</AnimatePresence>;
}

export default function App() {
  const [cart,setCart] = useState([]);
  const [cartOpen,setCartOpen] = useState(false);
  const [checkoutOpen,setCheckoutOpen] = useState(false);
  const [filter,setFilter] = useState('All pizzas');
  const [customizing,setCustomizing] = useState(null);
  const [size,setSize] = useState('Regular');
  const [selectedToppings,setSelectedToppings] = useState([]);
  const [mobileNav,setMobileNav] = useState(false);
  const [orderSuccess,setOrderSuccess] = useState(null);
  const cartCount = cart.reduce((s,i)=>s+i.qty,0);
  const filtered = useMemo(()=>filter==='All pizzas'?pizzas:pizzas.filter(p=>p.category===filter),[filter]);

  const openCustomize = pizza => { setCustomizing(pizza); setSize('Regular'); setSelectedToppings([]); };
  const addToCart = () => {
    if (!customizing) return;
    const sizeExtra = size === 'Large' ? 3 : size === 'Small' ? -2 : 0;
    const price = Math.max(0,customizing.price+sizeExtra+selectedToppings.length*1);
    const key = `${customizing.id}-${size}-${selectedToppings.slice().sort().join('|')}`;
    setCart(old=>{const found=old.find(i=>i.key===key);return found?old.map(i=>i.key===key?{...i,qty:i.qty+1}:i):[...old,{key,id:customizing.id,name:customizing.name,image:customizing.image,price,qty:1,size,toppings:selectedToppings}]});
    setCustomizing(null); setCartOpen(true);
  };
  const startCheckout = () => { setCartOpen(false); setCheckoutOpen(true); };
  const finishOrder = order => { setOrderSuccess(order); setCart([]); };

  return <div className="app-shell">
    <div className="announcement"><Flame size={13} fill="currentColor"/> HAND-STRETCHED. FIRE-BAKED. ALWAYS FRESH. <span>TAKEAWAY, THE SOL WAY.</span></div>
    <Header cartCount={cartCount} onCart={()=>setCartOpen(true)} onMenu={()=>setMobileNav(v=>!v)}/>
    <AnimatePresence>{mobileNav && <motion.div className="mobile-nav-panel" initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}}><a href="#menu" onClick={()=>setMobileNav(false)}>The menu</a><a href="#story" onClick={()=>setMobileNav(false)}>Our craft</a><a href="#pickup" onClick={()=>setMobileNav(false)}>Pickup info</a></motion.div>}</AnimatePresence>

    <main>
      <section className="hero" id="home">
        <div className="hero-copy">
          <div className="hero-kicker"><span className="kicker-line"/><span>YOUR LOCAL PIZZA RITUAL</span></div>
          <h1>Fired by<br/><em>passion.</em><br/>Made for <span>you.</span></h1>
          <p className="hero-description">Slow-made dough. Big Italian flavour. Straight from our oven to your hands.</p>
          <div className="hero-buttons"><a className="button button-primary" href="#menu">Explore the menu <ArrowUpRight size={17}/></a><a className="text-link" href="#story">Our way of making it <span>↗</span></a></div>
          <div className="hero-proof"><div className="proof-icon"><Clock3 size={17}/></div><div><strong>Made fresh to order</strong><small>Ready for pickup in 20–30 min</small></div><span className="proof-divider"/><div className="proof-stars">★★★★★<small>Made with care</small></div></div>
        </div>
        <div className="hero-visual"><div className="hero-visual-glow"/><div className="hero-stamp"><span>FRESH</span><strong>DAILY</strong><small>EST. WITH LOVE</small></div><PizzaScene/><div className="hero-note"><span className="note-number">01</span><span>THE SIGNATURE<br/><strong>SOL PIZZA</strong></span><span className="note-arrow">↘</span></div></div>
        <div className="hero-scroll"><span/> SCROLL TO DISCOVER</div>
      </section>

      <section className="ticker" aria-label="Our values"><div className="ticker-track">{Array.from({length:4}).map((_,i)=><React.Fragment key={i}><span>DOUGH WITH CHARACTER</span><i>✳</i><span>INGREDIENTS THAT SING</span><i>✳</i><span>FIRE MAKES THE DIFFERENCE</span><i>✳</i></React.Fragment>)}</div></section>

      <section className="menu-section section-wrap" id="menu">
        <div className="section-heading"><div><span className="eyebrow"><span className="tiny-flame">✦</span> THE GOOD STUFF</span><h2>Meet your <em>new favourite.</em></h2><p>Made from scratch, finished in fire, and ready when you are.</p></div><a href="#pickup" className="menu-pickup-link">Pickup made simple <ArrowUpRight size={16}/></a></div>
        <div className="menu-filters">{['All pizzas','Signature','Classics','Veggie'].map(f=><button key={f} className={filter===f?'filter-active':''} onClick={()=>setFilter(f)}>{f}</button>)}</div>
        <motion.div layout className="pizza-grid">{filtered.map((pizza,index)=><motion.article layout key={pizza.id} className="pizza-card" initial={{opacity:0,y:16}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.1}} transition={{delay:index*.06,duration:.4}}>
          <div className="pizza-card-art"><span className="pizza-tag">{pizza.tag}</span><PizzaArtwork kind={pizza.image}/><button className="quick-add" onClick={()=>openCustomize(pizza)} aria-label={`Customize ${pizza.name}`}><Plus size={20}/></button></div>
          <div className="pizza-card-body"><div className="pizza-card-title"><h3>{pizza.name}</h3><strong>{money(pizza.price)}</strong></div><p>{pizza.description}</p><button className="customize-link" onClick={()=>openCustomize(pizza)}>Customize pizza <ArrowUpRight size={14}/></button></div>
        </motion.article>)}</motion.div>
        <div className="menu-bottom"><span>GOOD FOOD. GOOD MOOD. NO SHORTCUTS.</span><span>MADE FRESH WHEN YOU ORDER <Flame size={14}/></span></div>
      </section>

      <section className="craft-section" id="story">
        <div className="craft-image"><div className="craft-image-orbit"><span>FIRE</span><span>FLAVOUR</span><span>FEELING</span></div><div className="craft-photo-label"><span>THE ART OF</span><strong>THE PERFECT CRUST</strong></div></div>
        <div className="craft-copy"><span className="eyebrow">A LITTLE HEAT. A LOT OF HEART.</span><h2>Good pizza<br/>isn't rushed.<br/><em>It's respected.</em></h2><p>We believe the best things start with simple ingredients, a little patience, and a very hot oven. Every pizza is built to order and baked until the crust is golden and the cheese is doing its thing.</p><div className="craft-points"><div><span className="craft-icon"><ChefHat size={19}/></span><div><strong>Made by hand</strong><small>Every dough ball gets the time it deserves.</small></div></div><div><span className="craft-icon"><Flame size={19}/></span><div><strong>Finished in fire</strong><small>That char, that crunch, that first bite.</small></div></div></div><a href="#menu" className="button button-outline">Find your pizza <ArrowUpRight size={16}/></a></div>
      </section>

      <section className="pickup-section section-wrap" id="pickup"><div className="pickup-copy"><span className="eyebrow">YOU PICK THE TIME</span><h2>Hot pizza.<br/><em>Zero waiting around.</em></h2><p>Order ahead, swing by, and take your new favourite home. That's the Sol way.</p><a href="#menu" className="button button-primary">Order for pickup <ArrowUpRight size={17}/></a></div><div className="pickup-steps"><div className="pickup-step"><span>01</span><div><strong>Pick your pizza</strong><p>Find your go-to or try something new.</p></div><ArrowUpRight size={17}/></div><div className="pickup-step"><span>02</span><div><strong>Choose pickup</strong><p>Tell us when you'd like to collect.</p></div><ArrowUpRight size={17}/></div><div className="pickup-step"><span>03</span><div><strong>Grab & enjoy</strong><p>Fresh from our oven, straight to you.</p></div><ArrowUpRight size={17}/></div><div className="pickup-location"><MapPin size={18}/><div><strong>Your neighbourhood pizzeria</strong><small>Address and opening hours can be added here.</small></div></div></div></section>

      <section className="final-cta"><div className="final-cta-inner"><span className="eyebrow">YOUR NEXT GREAT BITE IS CLOSE</span><h2>It's always a good time<br/>for <em>pizza.</em></h2><a href="#menu" className="button button-light">Let's get ordering <ArrowUpRight size={17}/></a><div className="cta-sun">✳</div></div></section>
    </main>

    <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark"><Flame size={22}/></span><span><strong>PIZZERIA</strong><small>DEL SOL</small></span></a><span className="footer-motto">MADE WITH FIRE. SERVED WITH HEART.</span><span className="footer-copy">© 2026 Pizzeria del Sol · Demo website</span></footer>

    <CartDrawer open={cartOpen} onClose={()=>setCartOpen(false)} cart={cart} setCart={setCart} onCheckout={startCheckout}/>
    <CheckoutModal open={checkoutOpen} onClose={()=>setCheckoutOpen(false)} cart={cart} onSuccess={finishOrder}/>

    <AnimatePresence>{customizing && <motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={()=>setCustomizing(null)}>
      <motion.div className="customize-modal" initial={{opacity:0,y:20,scale:.98}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:12}} onClick={e=>e.stopPropagation()}>
        <button className="modal-close icon-button" onClick={()=>setCustomizing(null)}><X/></button>
        <div className="customize-art"><PizzaArtwork kind={customizing.image}/></div>
        <div className="customize-content"><span className="eyebrow">MAKE IT YOURS</span><h2>{customizing.name}</h2><p>{customizing.description}</p>
          <span className="option-label">CHOOSE YOUR SIZE</span><div className="size-options">{[['Small',-2],['Regular',0],['Large',3]].map(([s])=><button key={s} className={size===s?'size-active':''} onClick={()=>setSize(s)}><span>{s}</span><small>{s==='Small'?'10″':s==='Regular'?'12″':'14″'}</small></button>)}</div>
          <span className="option-label">ADD TOPPINGS <small>+ €1 EACH</small></span><div className="topping-options">{['Extra mozzarella','Pepperoni','Mushrooms','Olives'].map(t=><label key={t}><input type="checkbox" checked={selectedToppings.includes(t)} onChange={e=>setSelectedToppings(old=>e.target.checked?[...old,t]:old.filter(x=>x!==t))}/><span>{t}</span><b>+€1</b></label>)}</div>
          <button className="button button-primary button-full add-to-cart" onClick={addToCart}>Add to order <strong>{money(Math.max(0,customizing.price+(size==='Large'?3:size==='Small'?-2:0)+selectedToppings.length))}</strong><Plus size={17}/></button>
        </div>
      </motion.div>
    </motion.div>}</AnimatePresence>
  </div>;
}
